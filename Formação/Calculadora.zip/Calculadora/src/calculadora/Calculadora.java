package calculadora;

public class Calculadora {

	
	public double somar(double valor1, double valor2) {
		double resultado;
		resultado = valor1 + valor2;
		return resultado;
	}
	
	public double subtrair(double valor1, double valor2) {
		double resultado;
		resultado = valor1 - valor2;
		return resultado;
	}
	
	public double multiplicar(double valor1, double valor2) {
		double resultado;
		resultado = valor1 * valor2;
		return resultado;
	}
	
	public double dividir(double valor1, double valor2) {
		double resultado;
		resultado = valor1 / valor2;
		return resultado;
	}
}
