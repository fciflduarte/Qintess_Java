
public class Somar {

	public static void main(String[] args) {
		
		int valor1, valor2, resultado;
		valor1 = 10;
		valor2 = 20;
		resultado = valor1 + valor2;
		System.out.println(valor1 + " + " + valor2 + " = " + resultado);
	}

}
