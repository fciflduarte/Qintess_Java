

public class ParImpar {
	
		public static void main(String[] args) {
		
		int valor = 8;
		System.out.println((valor % 2) ==0 ? "Par": "Impar");
	}


}
